# cinema_app_ui

## Support

<p>
<a href="https://sociabuzz.com/syarifhidayatullah2020/tribe" target='_blank'>
<img src="https://sociabuzz.s3.ap-southeast-1.amazonaws.com//landing-page/img/sociabuzz-logo.png" width="100"></a>

<a href="https://www.buymeacoffee.com/syarifhidayat"  target='_blank'>
<img src="https://media.tenor.com/Is0ELiJnoU0AAAAi/buymeacoffee-button.gif" width="100"></a>
</p>

## UI/UX

<a href="https://dribbble.com/shots/16222673-Pilm-Cinema-Booking-App"  target='_blank'><img src="https://upload.wikimedia.org/wikipedia/commons/3/32/Dribbble_logo.png" width="100"></a>

## Youtube

<a href="https://youtu.be/OwjgbhAJ8xA" target='_blank'>
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/YouTube_Logo_2017.svg/200px-YouTube_Logo_2017.svg.png" width="100"></a>

## Preview

<p align="middle">
<img src="assets/previews/home.png" alt="Home Page" width="200">
<img src="assets/previews/detail.png" alt="Detail Page" width="200">
<img src="assets/previews/reservation.png" alt="Reservation Page" width="200">
</p>
