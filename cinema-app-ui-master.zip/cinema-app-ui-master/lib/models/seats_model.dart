List<String> numRow = ['A', 'B', 'C', 'D', 'E', 'F'];
List<String> selectedSeats = [];
List<String> reservedSeats = [
  'A3',
  'B7',
  'C2',
  'C3',
  'E2',
  'E3',
  'E6',
  'E7',
  'E8',
  'F4'
];
List<String> availableTime = [
  '09:00',
  '11:00',
  '13:00',
  '15:00',
  '17:00',
  '19:00',
  '21:00'
];
